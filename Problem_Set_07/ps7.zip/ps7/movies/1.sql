--write a SQL query to list the titles of all movies released in 2008
SELECT title FROM movies 
WHERE YEAR=2008;