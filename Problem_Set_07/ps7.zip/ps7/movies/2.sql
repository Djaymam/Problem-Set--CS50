--write a SQL query to determine the birth year of Emma Stone
SELECT birth FROM people 
WHERE name='Emma Stone';